from flask import Flask, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_cors import CORS
from datetime import datetime, timedelta
import jwt
import os
from pyngrok import ngrok

app = Flask(__name__, static_folder='.')
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this in production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database/delegate.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Models
class Delegate(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    status = db.Column(db.String(20), default='active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)

class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    delegate_id = db.Column(db.Integer, db.ForeignKey('delegate.id'))
    check_type = db.Column(db.String(10))
    location_lat = db.Column(db.Float)
    location_lng = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class CashSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    delegate_id = db.Column(db.Integer, db.ForeignKey('delegate.id'))
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    submission_date = db.Column(db.DateTime, default=datetime.utcnow)

class DelegateLocation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    delegate_id = db.Column(db.Integer, db.ForeignKey('delegate.id'))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return Delegate.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    phone = data.get('phone')
    password = data.get('password')
    
    delegate = Delegate.query.filter_by(phone=phone).first()
    if delegate and bcrypt.check_password_hash(delegate.password_hash, password):
        delegate.last_login = datetime.utcnow()
        db.session.commit()
        token = jwt.encode(
            {'user_id': delegate.id, 'exp': datetime.utcnow() + timedelta(days=1)},
            app.config['SECRET_KEY']
        )
        return jsonify({'token': token, 'name': delegate.name})
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/mark-attendance', methods=['POST'])
@login_required
def mark_attendance():
    data = request.get_json()
    new_attendance = Attendance(
        delegate_id=current_user.id,
        check_type=data.get('type'),
        location_lat=data.get('lat'),
        location_lng=data.get('lng')
    )
    db.session.add(new_attendance)
    db.session.commit()
    return jsonify({'message': 'Attendance marked successfully'})

@app.route('/submit-cash', methods=['POST'])
@login_required
def submit_cash():
    data = request.get_json()
    new_submission = CashSubmission(
        delegate_id=current_user.id,
        amount=data.get('amount')
    )
    db.session.add(new_submission)
    db.session.commit()
    return jsonify({'message': 'Cash submission recorded successfully'})

# Admin routes
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    return send_from_directory('.', 'admin.html')

@app.route('/api/reports/attendance', methods=['GET'])
@login_required
def attendance_report():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Attendance.query
    if start_date:
        query = query.filter(Attendance.timestamp >= start_date)
    if end_date:
        query = query.filter(Attendance.timestamp <= end_date)
    
    attendances = query.all()
    return jsonify([{
        'delegate_name': Delegate.query.get(a.delegate_id).name,
        'check_type': a.check_type,
        'location': {'lat': a.location_lat, 'lng': a.location_lng},
        'timestamp': a.timestamp.strftime('%Y-%m-%d %H:%M:%S')
    } for a in attendances])

@app.route('/api/reports/cash', methods=['GET'])
@login_required
def cash_report():
    submissions = CashSubmission.query.all()
    return jsonify([{
        'delegate_name': Delegate.query.get(s.delegate_id).name,
        'amount': s.amount,
        'status': s.status,
        'date': s.submission_date.strftime('%Y-%m-%d %H:%M:%S')
    } for s in submissions])

@app.route('/api/delegate/location', methods=['POST'])
@login_required
def update_location():
    data = request.get_json()
    new_location = DelegateLocation(
        delegate_id=current_user.id,
        latitude=data.get('lat'),
        longitude=data.get('lng'),
        timestamp=datetime.utcnow()
    )
    db.session.add(new_location)
    db.session.commit()
    return jsonify({'message': 'Location updated successfully'})

# Create test data
def create_test_data():
    with app.app_context():
        db.create_all()
        
        # Create test delegate if not exists
        if not Delegate.query.filter_by(phone='123456789').first():
            test_delegate = Delegate(
                name='Test Delegate',
                phone='123456789',
                password_hash=bcrypt.generate_password_hash('password123').decode('utf-8')
            )
            db.session.add(test_delegate)
        
        # Create test admin if not exists
        if not Admin.query.filter_by(username='admin').first():
            test_admin = Admin(
                username='admin',
                password_hash=bcrypt.generate_password_hash('admin123').decode('utf-8')
            )
            db.session.add(test_admin)
        
        db.session.commit()

if __name__ == '__main__':
    create_test_data()
    print(" * Running on all interfaces (0.0.0.0)")
    print(" * Access locally via: http://localhost")
    print(" * Access from other devices via: http://[YOUR_IP_ADDRESS]")
    app.run(debug=True, host='0.0.0.0', port=80)
