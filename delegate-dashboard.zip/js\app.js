let currentLanguage = 'ar';
let isLoggedIn = false;
let locationInterval;
let currentDelegateId = null;
const API_BASE_URL = 'http://localhost:5000/api';

const translations = {
    ar: {
        logoutSuccess: 'تم تسجيل الخروج بنجاح',
        loginError: 'حدث خطأ في تسجيل الدخول. يرجى المحاولة مرة أخرى',
        fillAllFields: 'يرجى إدخال جميع الحقول',
        checkedIn: 'تم تسجيل الحضور',
        checkedOut: 'تم تسجيل الانصراف',
        at: 'في',
        attendanceError: 'حدث خطأ في تسجيل الحضور',
        cashSubmitted: 'تم تسليم {amount} ريال مع الإيصال',
        cashError: 'حدث خطأ في تسليم النقد',
        sharingLocation: 'جارٍ مشاركة الموقع: ({lat}, {lng})',
        locationError: 'حدث خطأ في تحديد الموقع',
        browserNotSupported: 'متصفحك لا يدعم تحديد الموقع',
        locationStopped: 'تم إيقاف مشاركة الموقع'
    },
    bn: {
        logoutSuccess: 'সফলভাবে লগআউট হয়েছে',
        loginError: 'লগইন করতে সমস্যা হচ্ছে। আবার চেষ্টা করুন',
        fillAllFields: 'সব ক্ষেত্র পূরণ করুন',
        checkedIn: 'চেক-ইন করা হয়েছে',
        checkedOut: 'চেক-আউট করা হয়েছে',
        at: 'সময়',
        attendanceError: 'উপস্থিতি নথিভুক্ত করতে সমস্যা',
        cashSubmitted: '{amount} রিয়াল রসিদসহ জমা দেওয়া হয়েছে',
        cashError: 'নগদ জমা দিতে সমস্যা',
        sharingLocation: 'অবস্থান শেয়ার করা হচ্ছে: ({lat}, {lng})',
        locationError: 'অবস্থান পেতে সমস্যা',
        browserNotSupported: 'আপনার ব্রাউজার লোকেশন শেয়ারিং সমর্থন করে না',
        locationStopped: 'অবস্থান শেয়ারিং বন্ধ করা হয়েছে'
    },
    en: {
        logoutSuccess: 'Logged out successfully',
        loginError: 'Error logging in. Please try again',
        fillAllFields: 'Please fill in all fields',
        checkedIn: 'Checked in',
        checkedOut: 'Checked out',
        at: 'at',
        attendanceError: 'Error marking attendance',
        cashSubmitted: 'Submitted SAR {amount} with receipt',
        cashError: 'Error submitting cash',
        sharingLocation: 'Sharing location: ({lat}, {lng})',
        locationError: 'Error getting location',
        browserNotSupported: 'Geolocation is not supported by your browser',
        locationStopped: 'Location sharing stopped'
    }
};

// Language Setting
function setLanguage(lang) {
    currentLanguage = lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    
    document.querySelectorAll('[data-ar]').forEach(element => {
        element.textContent = element.getAttribute(`data-${lang}`);
    });
}

// Get translation
function getTranslation(key, replacements = {}) {
    let text = translations[currentLanguage][key];
    Object.keys(replacements).forEach(key => {
        text = text.replace(`{${key}}`, replacements[key]);
    });
    return text;
}

// Logout Function
function logout() {
    isLoggedIn = false;
    currentDelegateId = null;
    document.getElementById('main-nav').classList.add('d-none');
    document.getElementById('main-content').classList.add('d-none');
    document.getElementById('login-section').classList.remove('d-none');
    
    document.getElementById('login-form').reset();
    document.getElementById('cash-form').reset();
    
    stopLocationSharing();
    
    alert(getTranslation('logoutSuccess'));
}

// Login Handler
document.getElementById('login-form').addEventListener('submit', async function(event) {
    event.preventDefault();
    const name = document.getElementById('delegateName').value;
    const phone = document.getElementById('delegatePhone').value;

    if (name && phone) {
        try {
            const response = await fetch(`${API_BASE_URL}/delegate/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, phone })
            });
            
            const data = await response.json();
            
            if (data.success) {
                isLoggedIn = true;
                currentDelegateId = data.delegate_id;
                document.getElementById('login-section').classList.add('d-none');
                document.getElementById('main-nav').classList.remove('d-none');
                document.getElementById('main-content').classList.remove('d-none');
            }
        } catch (error) {
            alert(getTranslation('loginError'));
        }
    } else {
        alert(getTranslation('fillAllFields'));
    }
});

// Attendance Marking
async function markAttendance(type) {
    const statusElement = document.getElementById('attendance-status');
    
    try {
        const response = await fetch(`${API_BASE_URL}/attendance`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                delegate_id: currentDelegateId,
                check_type: type
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const now = new Date().toLocaleString(currentLanguage === 'ar' ? 'ar-SA' : 'bn-BD');
            statusElement.style.backgroundColor = type === 'in' ? '#d4edda' : '#f8d7da';
            statusElement.style.color = type === 'in' ? '#155724' : '#721c24';
            
            const status = type === 'in' ? getTranslation('checkedIn') : getTranslation('checkedOut');
            statusElement.textContent = `${status} ${getTranslation('at')} ${now}`;
        }
    } catch (error) {
        statusElement.style.backgroundColor = '#f8d7da';
        statusElement.style.color = '#721c24';
        statusElement.textContent = getTranslation('attendanceError');
    }
}

// Cash Submission Handler
document.getElementById('cash-form').addEventListener('submit', async function(event) {
    event.preventDefault();
    const amount = document.getElementById('cashAmount').value;
    const receipt = document.getElementById('cashReceipt').files[0];
    const statusElement = document.getElementById('cash-status');

    if (amount && receipt) {
        const formData = new FormData();
        formData.append('delegate_id', currentDelegateId);
        formData.append('amount', amount);
        formData.append('receipt', receipt);

        try {
            const response = await fetch(`${API_BASE_URL}/cash/submit`, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                statusElement.style.backgroundColor = '#d4edda';
                statusElement.style.color = '#155724';
                statusElement.textContent = getTranslation('cashSubmitted', { amount });
                this.reset();
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            statusElement.style.backgroundColor = '#f8d7da';
            statusElement.style.color = '#721c24';
            statusElement.textContent = getTranslation('cashError');
        }
    } else {
        statusElement.style.backgroundColor = '#f8d7da';
        statusElement.style.color = '#721c24';
        statusElement.textContent = getTranslation('fillAllFields');
    }
});

// Location Sharing Functions
async function logLocation(position) {
    try {
        await fetch(`${API_BASE_URL}/location/log`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                delegate_id: currentDelegateId,
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            })
        });
    } catch (error) {
        console.error('Error logging location:', error);
    }
}

function startLocationSharing() {
    const statusElement = document.getElementById('location-status');
    
    if (navigator.geolocation) {
        statusElement.style.backgroundColor = '#d4edda';
        statusElement.style.color = '#155724';
        
        locationInterval = setInterval(() => {
            navigator.geolocation.getCurrentPosition(async position => {
                const { latitude, longitude } = position.coords;
                await logLocation(position);
                
                statusElement.textContent = getTranslation('sharingLocation', {
                    lat: latitude.toFixed(6),
                    lng: longitude.toFixed(6)
                });
            }, error => {
                statusElement.style.backgroundColor = '#f8d7da';
                statusElement.style.color = '#721c24';
                statusElement.textContent = getTranslation('locationError');
            });
        }, 5000);
    } else {
        statusElement.style.backgroundColor = '#f8d7da';
        statusElement.style.color = '#721c24';
        statusElement.textContent = getTranslation('browserNotSupported');
    }
}

function stopLocationSharing() {
    clearInterval(locationInterval);
    const statusElement = document.getElementById('location-status');
    statusElement.style.backgroundColor = '#f8d7da';
    statusElement.style.color = '#721c24';
    statusElement.textContent = getTranslation('locationStopped');
}

// Initialize with Arabic
setLanguage('ar');
