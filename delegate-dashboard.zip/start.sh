#!/bin/bash

# تثبيت المكتبات المطلوبة
pip install -r requirements.txt

# إنشاء مجلد قاعدة البيانات إذا لم يكن موجوداً
mkdir -p database

# تشغيل التطبيق باستخدام gunicorn
gunicorn --config gunicorn.conf.py app:app
